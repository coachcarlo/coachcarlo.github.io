import { startServer } from './server.js';

export default async () => {
  await startServer();
};
