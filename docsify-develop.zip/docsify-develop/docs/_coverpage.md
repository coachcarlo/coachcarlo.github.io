<!-- markdownlint-disable first-line-h1 -->

![logo](_media/icon.svg)

# docsify <small>4.13.0</small>

> A magical documentation site generator

- Simple and lightweight
- No statically built HTML files
- Multiple themes

[Get Started](#docsify)
[GitHub](https://github.com/docsifyjs/docsify/)

<!-- ![color](#f0f0f0) -->
<!-- ![](/_media/icon.svg) -->
